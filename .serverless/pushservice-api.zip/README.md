# serverless-push-api
This example demostrates how to use a serverless framework in aws lambda for FCM push notification
